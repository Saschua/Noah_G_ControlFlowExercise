import UIKit

let maxtime = 180

for timer in 0...maxtime
{
    print ("\timer) seconds")
    if timer == 180{
        print ("Time is up. Three minutes have passed.")
    }
}
